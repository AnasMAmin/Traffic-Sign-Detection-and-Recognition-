clc
clear all
close all
warning off

%----------------LOAD THE EXTRACTED FEATURES----------------%
 load hogfeatures_3
 load traininglabels_3
%  load classifier_95.mat
%-----------------PARTITIONING THE DATASET------------------%

cv = cvpartition(size(hogFeatures,1),'HoldOut',0.3);
idx = cv.test;
trainingLabels=trainingLabels';
tt=categorical;
for i=1:length(trainingLabels)
    tt(i)=categorical(trainingLabels{i,:});
end

tt=tt';
dataTrain=hogFeatures(~idx,:);
dataTrainL = tt(~idx,:);
dataTest=hogFeatures(idx,:);
dataTestL = tt(idx,:);
%-------------------TRAINING THE MODEL----------------------%


model = TreeBagger(700,dataTrain,dataTrainL,'OOBPrediction','On',...
     'Method','classification');
% 
 save('classifier.mat', 'model', '-v7.3');


%---------------------ACCURACY CALCULATION-----------------------%


[prediction, scores]=predict(model,dataTest);
Accuracy = (sum(prediction==dataTestL)/size(dataTest,1))*100;


%--------------------CALCULATING MODEL PERFORMANCE CURVES--------%
%-----------------------PRECISION vs RECALL----------------------%
prediction = categorical(prediction);
confmat = confusionmat(dataTestL, prediction);
confchart = confusionchart(dataTestL,prediction);
for i =1:size(confmat,1)
    recall(i)=confmat(i,i)/sum(confmat(i,:));
end

Recall = sum(rmmissing(recall))/size(confmat,1);
for i =1:size(confmat,1)
    precision(i)=confmat(i,i)/sum(confmat(:,i));
end
Precision=sum(rmmissing(precision))/size(confmat,1);
F_score=2*Recall*Precision/(Precision+Recall);
%---------------------ROC CURVE--------------------------------%
figure;
title('ROC curve');
k = 2;
    [X,Y,t,AUC] = perfcurve(dataTestL,scores(:,k),k-1);
    plot(X,Y);
    plot(X,Y,'LineWidth',1.25,'Color','b');
    xlabel('False positive rate');
    ylabel('True positive rate');
    title('ROC for classification-AUC',num2str(AUC));
   [Xr,Yp,tpr,AUC_pr] = perfcurve(dataTestL,scores(:,k),k-1,'Xcrit','reca','YCrit','prec');
    figure;
    plot(Xr,Yp,'LineWidth',1.25,'Color','r');
    xlabel('Recall');
    ylabel('Precision');
    title('PR curve-AUC', num2str(AUC_pr));