Datasets used:

GTSDB (Testing Data)
https://www.kaggle.com/datasets/safabouguezzi/german-traffic-sign-detection-benchmark-gtsdb
GTSRB (Traning Data)
https://www.kaggle.com/datasets/meowmeowmeowmeowmeow/gtsrb-german-traffic-sign


Open the (Hog Feature Extraction file) make the required changes upon your requirement and run it.
HOG Features will be saved to avoid extraction for every execution.

We only use 16000 random Picture from GTSRB (data set)


Open the (Training and Model Accuracy file) to train the model with extracted features.
Change the number of decision trees for your desired accuracy! Also, check the ROC-AUC and Precision-Recall curves.

The model will be saved locally.
Saving time varies from computer to computer

Move all masks to the current directory so that, the Main Function file will be on the same level as the masks.
Run the Main Function file and you are good to go!!....
