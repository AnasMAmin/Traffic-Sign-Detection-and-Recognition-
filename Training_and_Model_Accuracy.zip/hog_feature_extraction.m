clc;
clear all;
close all;
warning off;
%---------------CHANGE PATH TO TRAINING IMAGES FOLDER------------%
imds = imageDatastore('D:\Master\Master Matrials\Second Term\DSP\Project\archive_2\', 'IncludeSubFolders', true, 'LabelSource', 'foldernames');
% Get the total number of images
totalImages = numel(imds.Files);

% Set the desired number of pictures to choose (e.g., 16000)
desiredNumPictures = 16000;

% Randomly select indices for the images
selectedIndices = randperm(totalImages, desiredNumPictures);

% Initialize arrays for features and labels

hogFeatures = []; % Adjust the size based on your HOG feature dimensions
trainingLabels = categorical;
% Loop through the selected indices
for i = 1:desiredNumPictures
    

    currentIndex = selectedIndices(i);
    im = readimage(imds, currentIndex);
    im = imresize(im, [200 200]);
    disp(i); % DISPLAYS THE COUNT OF IMAGES
    hogFeatures(i, :) = extractHOGFeatures(im, 'CellSize', [8 8]);
    trainingLabels(i) = imds.Labels(currentIndex);


end

%--------------TO SAVE THE EXTRACTED FEATURES-----------------%
save('hogfeatures.mat', 'hogFeatures', '-v7.3')
save('traininglabels.mat', 'trainingLabels', '-v7.3')
