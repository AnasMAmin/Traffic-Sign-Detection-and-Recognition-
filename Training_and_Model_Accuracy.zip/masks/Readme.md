This is masks folder

Here masks are of red, blue and yellow colours

you can make masks of your own and add them to the rybmasks function
